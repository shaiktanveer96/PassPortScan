# Detect-text-in-an-image-using-Amazon-Rekognition

Use python 3.7.9

# steps to run code

1 Create aws account if not created yet.
  Link - for creation - https://aws.amazon.com/
  
2 Create a **user** using IAM management Console in aws account with one Policy named as **AmazonRekognitionFullAccess**
  After creating user it will provide a csv file which contains credentials . 
  
  csv file name - new_user_credentials.csv
  
3 Download csv file and copy that file to Detect-text-in-an-image-using-Amazon-Rekognition Directory

4 Install all library mentioned in requiremets.txt

5 then run app.py file.


# video - https://youtu.be/Zhu67fHY1Rk
